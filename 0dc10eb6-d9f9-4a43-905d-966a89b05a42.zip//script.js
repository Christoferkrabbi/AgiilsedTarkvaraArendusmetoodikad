var nameList = [
  "Time",
  "Past",
  "Future",
  "Dev",
  "Fly",
  "Flying",
  "Soar",
  "Soaring",
  "Power",
  "Falling",
  "Fall",
  "Jump",
  "Cliff",
  "Mountain",
  "Rend",
  "Red",
  "Blue",
  "Green",
  "Yellow",
  "Gold",
  "Demon",
  "Demonic",
  "Panda",
  "Cat",
  "Kitty",
  "Kitten",
  "Zero",
  "Memory",
  "Trooper",
  "XX",
  "Bandit",
  "Fear",
  "Light",
  "Glow",
  "Tread",
  "Deep",
  "Deeper",
  "Deepest",
  "Mine",
  "Your",
  "Worst",
  "Enemy",
  "Hostile",
  "Force",
  "Video",
];

class Platform {
  constructor(resources) {
    this.resources = resources;
  }
}

class Level {
  constructor(lvl, peopleList) {
    this.lvl = lvl;
    this.peopleList = peopleList;
  }
}

class People {
  constructor(name, age, item) {
    this.name = name;
    this.age = age;
    this.item = item;
  }
  consume(platform, lvl) {
    const amount = 10;
    platform.resources -= amount;
  }
}

platform1 = new Platform(100);
let lvls = [];

for (let i = 0; i < 10; i++) {
  let people1 = new People(
    nameList[Math.floor(Math.random() * nameList.length)],
    Math.floor(Math.random() * 100)
  );
  let people2 = new People(
    nameList[Math.floor(Math.random() * nameList.length)],
    Math.floor(Math.random() * 100)
  );

  let lvl = new Level(i, [people1, people2]);
  lvls.push(lvl);
}

lvls.forEach((element) => {
  element.peopleList[0].consume(platform1);
  element.peopleList[1].consume(platform1);
  console.log(platform1);
});
